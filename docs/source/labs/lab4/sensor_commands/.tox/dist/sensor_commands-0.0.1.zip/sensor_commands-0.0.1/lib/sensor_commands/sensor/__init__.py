"""
sensor module entry point.
"""
