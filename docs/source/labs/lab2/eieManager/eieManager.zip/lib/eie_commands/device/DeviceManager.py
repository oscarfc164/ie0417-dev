import json
from typing import Optional, List, Dict

from zmq import device

from ..Command import Command
from device import DeviceFactory


class DeviceManager:
    '''
    Manager class control for devices

    :param str config_filename: Name of the file with 
    devices info
    '''
    def __init__(self, config_filename: str) -> None:
        self.config_filename = config_filename
    


    def __init_devices(self):
        '''
        Initialize devices from json doc
        '''


    def init_config(self) -> None:
        '''
        Initializes the manager configuration
        '''
        with open(self.config_filename) as config_file:
            config_info = json.load(config_file)
            device_info = config_info("devices")
            # Create devices
            for device_info in device_info:
                name = device_info["name"]
                dtype = device_info["tipo"]
                self.devices[name] = self.device_factory(name, dtype)


    def create_device():
        """
        Creates and register new devices from dic and Device
        Factory
        """ 
    def destroy_device():
        """
        Destroys devices using the identificator
        """
    def send_command():
        """
        Sends commands to a device using identificator
        """