'''
eiemanager module entry point
'''

__author__ = 'Oscar Fallas Cordero'
__email__ = 'oscarsteven.fallas@ucr.ac.cr'
__version__ = '0.0.1'