from device import Device


class DeviceFactory():

    """
    Factory creates the dic with devices description
    """

    def __init__(self) -> None:
        self._device_desc = {
            "name":
            ""
        }